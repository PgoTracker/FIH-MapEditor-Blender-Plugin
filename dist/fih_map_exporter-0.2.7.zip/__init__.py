"""Export named Blender meshes as a Flipping Is Hard map package."""

bl_info = {
    "name": "Flipping Is Hard Map Exporter",
    "author": "FIH Map Editor contributors",
    "version": (0, 2, 7),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > FIH Map",
    "description": "Export scene meshes, matching textures and C# as .fihmap.zip",
    "category": "Import-Export",
}

import os
import tempfile
import math

import bpy
import bmesh
from bpy.props import BoolProperty, StringProperty
from bpy.types import Operator, Panel
from bpy_extras.io_utils import axis_conversion
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree

from .package import ExportError, asset_name, write_package


AXIS = axis_conversion(from_forward="Y", from_up="Z", to_forward="-Z", to_up="Y").to_4x4()
AXIS_INV = AXIS.inverted()


def _export_world_matrix(obj, depsgraph):
    world = obj.matrix_world.copy()
    if not getattr(obj, "fih_turn_for_game", False):
        return world
    evaluated = obj.evaluated_get(depsgraph)
    corners = [Vector(corner) for corner in evaluated.bound_box]
    local_center = sum(corners, Vector((0.0, 0.0, 0.0))) / len(corners)
    world_center = world @ local_center
    turn = (Matrix.Translation(world_center)
            @ Matrix.Rotation(math.pi, 4, "Z")
            @ Matrix.Translation(-world_center))
    return turn @ world


def _vec(values):
    return [round(float(value), 6) for value in values]


def _boundary_components(bm):
    remaining = {edge for edge in bm.edges if edge.is_boundary}
    components = []
    while remaining:
        component = set()
        queue = [next(iter(remaining))]
        while queue:
            edge = queue.pop()
            if edge in component:
                continue
            component.add(edge)
            remaining.discard(edge)
            for vertex in edge.verts:
                queue.extend(other for other in vertex.link_edges
                             if other.is_boundary and other not in component)
        components.append(component)
    return components


def _repair_matching_open_strip(mesh):
    """Bridge only two translation-matched boundary loops in a temporary mesh."""
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        if not any(edge.is_boundary for edge in bm.edges):
            return 0, False
        # This also removes the zero-area faces seen in TEST.blend. Work only
        # on the evaluated export copy; the user's Blender mesh is untouched.
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.000001)
        components = _boundary_components(bm)
        edge_count = sum(map(len, components))
        if len(components) != 2 or len(components[0]) != len(components[1]) or len(components[0]) < 3:
            return edge_count, False
        loops = []
        for component in components:
            vertices = {vertex for edge in component for vertex in edge.verts}
            if len(vertices) != len(component) or any(
                sum(edge in component for edge in vertex.link_edges) != 2 for vertex in vertices
            ):
                return edge_count, False
            loops.append(list(vertices))
        if len(loops[0]) > 5000:
            return edge_count, False
        centers = [sum((v.co for v in loop), Vector((0.0, 0.0, 0.0))) / len(loop) for loop in loops]
        delta = centers[1] - centers[0]
        span = max((vertex.co - centers[0]).length for loop in loops for vertex in loop)
        tolerance = max(0.00001, span * 0.00001)
        if delta.length <= tolerance:
            return edge_count, False
        tree = KDTree(len(loops[1]))
        for index, vertex in enumerate(loops[1]):
            tree.insert(vertex.co, index)
        tree.balance()
        matched = set()
        for vertex in loops[0]:
            _, index, distance = tree.find(vertex.co + delta)
            if distance > tolerance or index in matched:
                return edge_count, False
            matched.add(index)
            other = loops[1][index]
            if any(edge.other_vert(vertex) == other for edge in vertex.link_edges):
                # These loops already have a surface between them, such as the
                # open ends of a tube. Bridging would duplicate that surface.
                return edge_count, False
        original_loop = set(loops[0])
        opposite_loop = set(loops[1])
        existing_surface = BVHTree.FromBMesh(bm)
        bridge = bmesh.ops.bridge_loops(bm, edges=list(components[0] | components[1]))
        if len(bridge["faces"]) != len(loops[0]) or any(edge.is_boundary for edge in bm.edges):
            return edge_count, False
        covered_faces = 0
        for face in bridge["faces"]:
            center = sum((vertex.co for vertex in face.verts), Vector((0.0, 0.0, 0.0))) / len(face.verts)
            nearest = existing_surface.find_nearest(center)
            if nearest is not None and nearest[3] <= tolerance:
                covered_faces += 1
            for edge in face.edges:
                a, b = edge.verts
                if a in original_loop and b in opposite_loop:
                    offset = b.co - a.co
                elif b in original_loop and a in opposite_loop:
                    offset = a.co - b.co
                else:
                    continue
                if (offset - delta).length > tolerance:
                    return edge_count, False
        if covered_faces >= len(bridge["faces"]) * 0.1:
            # An open tube can have the same pair of end loops but already
            # have a wall between them. Do not add coplanar faces over it.
            return edge_count, False
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(mesh)
        mesh.update()
        return 0, True
    finally:
        bm.free()


def _obj_bytes(obj, depsgraph, require_uv=False, repair_open=False, repairs=None):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        if not mesh.vertices or not mesh.polygons:
            raise ExportError(f"{obj.name}: mesh has no faces")
        repaired = False
        if repair_open:
            _, repaired = _repair_matching_open_strip(mesh)
        if repaired:
            print(f"FIH Map Exporter: bridged matching open loops in {obj.name} for this export")
            if repairs is not None:
                repairs.append(obj.name)
        mesh.calc_loop_triangles()
        triangles = [triangle for triangle in mesh.loop_triangles
                     if (mesh.vertices[mesh.loops[triangle.loops[1]].vertex_index].co
                         - mesh.vertices[mesh.loops[triangle.loops[0]].vertex_index].co).cross(
                         mesh.vertices[mesh.loops[triangle.loops[2]].vertex_index].co
                         - mesh.vertices[mesh.loops[triangle.loops[0]].vertex_index].co).length_squared > 1e-16]
        if not triangles:
            raise ExportError(f"{obj.name}: mesh contains no non-degenerate faces")
        if len(triangles) * 3 > 250000:
            raise ExportError(f"{obj.name}: mesh has more face corners than the editor's 250,000-vertex limit")
        uv = mesh.uv_layers.active
        if require_uv and uv is None:
            raise ExportError(f"{obj.name}: textured mesh needs a UV map")
        axis = AXIS.to_3x3()
        lines = ["# FIH Map Exporter; local mesh coordinates\n"]
        for vertex in mesh.vertices:
            v = axis @ vertex.co
            lines.append(f"v {v.x:.9g} {v.y:.9g} {v.z:.9g}\n")
        # A UV and normal for every face corner preserves seams and sharp edges.
        for triangle in triangles:
            for loop_index in triangle.loops:
                if uv:
                    tex = uv.data[loop_index].uv
                    lines.append(f"vt {tex.x:.9g} {tex.y:.9g}\n")
                normal = axis @ mesh.corner_normals[loop_index].vector
                lines.append(f"vn {normal.x:.9g} {normal.y:.9g} {normal.z:.9g}\n")
        corner = 1
        for triangle in triangles:
            tokens = []
            for loop_index in triangle.loops:
                vertex_index = mesh.loops[loop_index].vertex_index + 1
                tokens.append(f"{vertex_index}/{corner}/{corner}" if uv else f"{vertex_index}//{corner}")
                corner += 1
            lines.append("f " + " ".join(tokens) + "\n")
        return "".join(lines).encode("ascii")
    finally:
        evaluated.to_mesh_clear()


def _texture_image(obj):
    images = set()
    untextured_material = False
    used_indices = {poly.material_index for poly in obj.data.polygons}
    for index in used_indices:
        material = obj.data.materials[index] if index < len(obj.data.materials) else None
        if material is None:
            untextured_material = True
            continue
        if not material.use_nodes:
            raise ExportError(f"{obj.name}: material {material.name} must use nodes")
        outputs = [node for node in material.node_tree.nodes if node.type == "OUTPUT_MATERIAL" and node.is_active_output]
        if not outputs:
            untextured_material = True
            continue
        surface = outputs[0].inputs.get("Surface")
        if not surface or not surface.is_linked:
            untextured_material = True
            continue
        shader = surface.links[0].from_node
        base = shader.inputs.get("Base Color")
        if not base or not base.is_linked:
            untextured_material = True
            continue
        source = base.links[0].from_node
        if source.type != "TEX_IMAGE" or source.image is None:
            raise ExportError(f"{obj.name}: Base Color must link directly to one Image Texture")
        images.add(source.image)
    if len(images) > 1:
        raise ExportError(f"{obj.name}: the map format supports one texture per asset; bake materials to one image")
    if images and untextured_material:
        raise ExportError(f"{obj.name}: textured and plain material faces need baking into one image")
    return next(iter(images)) if images else None


def _png_bytes(image, scene):
    if image.size[0] > 2048 or image.size[1] > 2048:
        raise ExportError(f"{image.name}: image exceeds 2048 x 2048")
    settings = scene.render.image_settings
    original = (settings.file_format, settings.color_mode, settings.color_depth)
    fd, path = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    try:
        settings.file_format = "PNG"
        settings.color_mode = "RGBA"
        settings.color_depth = "8"
        image.save_render(path, scene=scene)
        with open(path, "rb") as stream:
            return stream.read()
    finally:
        settings.file_format, settings.color_mode, settings.color_depth = original
        os.unlink(path)


def _script_bytes(name, scripts_dir):
    text = bpy.data.texts.get(name + ".cs")
    path = os.path.join(bpy.path.abspath(scripts_dir), name + ".cs") if scripts_dir else None
    if text and path and os.path.isfile(path):
        raise ExportError(f"{name}: C# exists in Blender Text and scripts folder; keep one copy")
    if text:
        return text.as_string().encode("utf-8")
    if path and os.path.isfile(path):
        with open(path, "rb") as stream:
            return stream.read()
    return None


def export_scene(scene, filepath, map_name, selected_only=False, scripts_dir="", depsgraph=None,
                 repair_open=False, repairs=None):
    depsgraph = depsgraph or bpy.context.evaluated_depsgraph_get()
    meshes = [obj for obj in scene.objects if obj.type == "MESH" and (not selected_only or obj.select_get())]
    meshes.sort(key=lambda obj: obj.name.lower())
    assets = {}
    objects = []
    for obj in meshes:
        name = asset_name(obj.name)
        image = _texture_image(obj)
        geometry = _obj_bytes(obj, depsgraph, require_uv=image is not None,
                              repair_open=repair_open, repairs=repairs)
        texture = _png_bytes(image, scene) if image else None
        key = name.lower()
        if key in assets:
            previous = assets[key]
            if previous[1]["obj"] != geometry or previous[1]["png"] != texture:
                raise ExportError(
                    f"{obj.name}: objects named {name} and {name}.001 must share the same local mesh "
                    "and texture. Give distinct meshes different names."
                )
            canonical = previous[0]
        else:
            canonical = name
            assets[key] = (name, {"obj": geometry, "png": texture, "cs": _script_bytes(name, scripts_dir)})
        converted = AXIS @ _export_world_matrix(obj, depsgraph) @ AXIS_INV
        position, rotation, scale = converted.decompose()
        if min(scale) <= 0:
            raise ExportError(f"{obj.name}: apply mirror or negative scale before export")
        reconstructed = Matrix.LocRotScale(position, rotation, scale)
        if any(abs(converted[row][col] - reconstructed[row][col]) > 0.0001
               for row in range(4) for col in range(4)):
            raise ExportError(f"{obj.name}: transform contains shear; apply transforms before export")
        # Unity Quaternion.Euler(x,y,z) uses the YXZ rotation order.
        angles = rotation.to_euler("YXZ")
        objects.append({
            "Source": "package://" + canonical,
            "SourceName": canonical,
            "Pos": _vec(position),
            "Rot": _vec(math.degrees(angle) for angle in angles),
            "Scale": _vec(scale),
        })
    return write_package(filepath, map_name, objects, {value[0]: value[1] for value in assets.values()})


class FIH_OT_export(Operator):
    bl_idname = "fih.export_map_package"
    bl_label = "Export Map Package"
    bl_description = "Create a .fihmap.zip from named mesh objects in this scene"

    def execute(self, context):
        scene = context.scene
        try:
            path = bpy.path.abspath(scene.fih_output_path)
            if not path.lower().endswith(".fihmap.zip"):
                path += ".fihmap.zip"
            repairs = []
            export_scene(scene, path, scene.fih_map_name, scene.fih_selected_only, scene.fih_scripts_dir,
                         repair_open=scene.fih_repair_open, repairs=repairs)
        except (ExportError, OSError, RuntimeError) as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"Exported {path}; auto-repaired {len(repairs)} mesh(es)")
        return {"FINISHED"}


class FIH_PT_export(Panel):
    bl_label = "FIH Map"
    bl_idname = "FIH_PT_export"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "FIH Map"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.prop(scene, "fih_map_name")
        layout.prop(scene, "fih_output_path")
        layout.prop(scene, "fih_selected_only")
        layout.prop(scene, "fih_repair_open")
        if context.active_object and context.active_object.type == "MESH":
            layout.prop(context.active_object, "fih_turn_for_game")
        layout.prop(scene, "fih_scripts_dir")
        layout.operator(FIH_OT_export.bl_idname, icon="EXPORT")


CLASSES = (FIH_OT_export, FIH_PT_export)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fih_map_name = StringProperty(name="Map Name", default="Blender Map")
    bpy.types.Scene.fih_output_path = StringProperty(name="Package", subtype="FILE_PATH", default="//BlenderMap.fihmap.zip")
    bpy.types.Scene.fih_selected_only = BoolProperty(name="Selected Meshes Only", default=False)
    bpy.types.Scene.fih_repair_open = BoolProperty(name="Repair Matching Gaps", default=False,
                                                  description="Bridge two matching open edge loops in the export copy")
    bpy.types.Object.fih_turn_for_game = BoolProperty(
        name="Turn Around in Game", default=False,
        description="Turn this placement 180 degrees around Blender's vertical axis about its center in the exported map")
    bpy.types.Scene.fih_scripts_dir = StringProperty(name="C# Scripts Folder", subtype="DIR_PATH", default="")


def unregister():
    del bpy.types.Object.fih_turn_for_game
    for key in ("fih_map_name", "fih_output_path", "fih_selected_only", "fih_repair_open",
                "fih_scripts_dir"):
        delattr(bpy.types.Scene, key)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
