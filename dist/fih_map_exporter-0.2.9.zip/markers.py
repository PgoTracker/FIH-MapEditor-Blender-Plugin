"""Blender-only visual markers for map spawn, goal, and checkpoints."""

import bpy


COLORS = {
    "Spawn": (0.08, 0.54, 0.95),
    "Goal": (0.16, 0.77, 0.31),
    "Checkpoint": (1.0, 0.57, 0.09),
}

GLYPHS = {
    "A": ("01110", "10001", "10001", "11111", "10001", "10001", "10001"),
    "C": ("01111", "10000", "10000", "10000", "10000", "10000", "01111"),
    "E": ("11111", "10000", "10000", "11110", "10000", "10000", "11111"),
    "G": ("01111", "10000", "10000", "10111", "10001", "10001", "01111"),
    "H": ("10001", "10001", "10001", "11111", "10001", "10001", "10001"),
    "I": ("11111", "00100", "00100", "00100", "00100", "00100", "11111"),
    "K": ("10001", "10010", "10100", "11000", "10100", "10010", "10001"),
    "L": ("10000", "10000", "10000", "10000", "10000", "10000", "11111"),
    "N": ("10001", "11001", "10101", "10101", "10011", "10001", "10001"),
    "O": ("01110", "10001", "10001", "10001", "10001", "10001", "01110"),
    "P": ("11110", "10001", "10001", "11110", "10000", "10000", "10000"),
    "S": ("01111", "10000", "10000", "01110", "00001", "00001", "11110"),
    "T": ("11111", "00100", "00100", "00100", "00100", "00100", "00100"),
    "W": ("10001", "10001", "10001", "10101", "10101", "10101", "01010"),
}


def _marker_image(kind):
    name = f"FIH {kind} Marker Texture"
    image = bpy.data.images.get(name)
    if image and tuple(image.size) == (256, 256):
        return image
    image = bpy.data.images.new(name, width=256, height=256, alpha=True)
    tint = COLORS[kind]
    dark = tuple(channel * 0.16 for channel in tint) + (1.0,)
    bright = tuple(min(1.0, channel * 1.25) for channel in tint) + (1.0,)
    white = (1.0, 1.0, 1.0, 1.0)
    pixels = list(dark) * (256 * 256)

    def dot(x, y, color):
        if 0 <= x < 256 and 0 <= y < 256:
            offset = ((255 - y) * 256 + x) * 4
            pixels[offset:offset + 4] = color

    def rect(x0, y0, x1, y1, color):
        for y in range(y0, y1):
            for x in range(x0, x1):
                dot(x, y, color)

    rect(0, 0, 256, 9, bright)
    rect(0, 247, 256, 256, bright)
    rect(0, 0, 9, 256, bright)
    rect(247, 0, 256, 256, bright)
    rect(16, 16, 240, 74, bright)
    label = kind.upper()
    glyph_scale = 3
    width = (len(label) * 6 - 1) * glyph_scale
    left = (256 - width) // 2
    for index, char in enumerate(label):
        for row, bits in enumerate(GLYPHS[char]):
            for col, bit in enumerate(bits):
                if bit == "1":
                    x = left + (index * 6 + col) * glyph_scale
                    y = 33 + row * glyph_scale
                    rect(x, y, x + glyph_scale, y + glyph_scale, white)
    # Arrow tip is at the top of the image, matching Blender local -Y.
    rect(113, 143, 143, 222, white)
    for y in range(94, 144):
        half_width = int((y - 94) * 0.9)
        rect(128 - half_width, y, 129 + half_width, y + 1, white)
    rect(55, 226, 201, 232, bright)
    image.pixels[:] = pixels
    image.update()
    image.pack()
    return image


def _marker_material(kind):
    name = f"FIH {kind} Marker Material"
    material = bpy.data.materials.get(name)
    if material is None:
        material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.diffuse_color = (*COLORS[kind], 1.0)
    nodes = material.node_tree.nodes
    nodes.clear()
    output = nodes.new("ShaderNodeOutputMaterial")
    emission = nodes.new("ShaderNodeEmission")
    texture = nodes.new("ShaderNodeTexImage")
    texture.image = _marker_image(kind)
    material.node_tree.links.new(texture.outputs["Color"], emission.inputs["Color"])
    material.node_tree.links.new(emission.outputs["Emission"], output.inputs["Surface"])
    return material


def _marker_mesh(kind):
    # The box dimensions are also the exporter's goal size / checkpoint diameter.
    half_xy = 2.0 if kind == "Goal" else 1.5 if kind == "Checkpoint" else 1.0
    half_z = 2.0 if kind == "Goal" else 0.1
    x, y, z = half_xy, half_xy, half_z
    sides = (
        ((-x, -y, z), (x, -y, z), (x, y, z), (-x, y, z)),
        ((-x, y, -z), (x, y, -z), (x, -y, -z), (-x, -y, -z)),
        ((-x, -y, -z), (x, -y, -z), (x, -y, z), (-x, -y, z)),
        ((x, y, -z), (-x, y, -z), (-x, y, z), (x, y, z)),
        ((x, -y, -z), (x, y, -z), (x, y, z), (x, -y, z)),
        ((-x, y, -z), (-x, -y, -z), (-x, -y, z), (-x, y, z)),
    )
    vertices = [point for side in sides for point in side]
    faces = [tuple(range(i * 4, i * 4 + 4)) for i in range(len(sides))]
    mesh = bpy.data.meshes.new(f"FIH {kind} Marker Shape")
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    uv = mesh.uv_layers.new(name="Marker Label")
    for polygon in mesh.polygons:
        for index, coordinate in zip(polygon.loop_indices, ((0, 1), (1, 1), (1, 0), (0, 0))):
            uv.data[index].uv = coordinate
    mesh.materials.append(_marker_material(kind))
    return mesh


def create_marker(context, kind):
    if kind in ("Spawn", "Goal") and any(
        (obj.name.rsplit(".", 1)[0] if obj.name.rsplit(".", 1)[-1].isdigit() else obj.name).casefold()
        == kind.casefold() for obj in context.scene.objects
    ):
        raise ValueError(f"This scene already has a {kind} marker")
    obj = bpy.data.objects.new(kind, _marker_mesh(kind))
    context.collection.objects.link(obj)
    obj.location = context.scene.cursor.location
    obj.color = (*COLORS[kind], 1.0)
    obj.show_name = True
    obj["fih_marker_kind"] = kind
    for other in context.selected_objects:
        other.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    return obj
